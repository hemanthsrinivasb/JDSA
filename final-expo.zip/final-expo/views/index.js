
    (function() {
     var s = document.createElement('script');s.type='text/javascript';s.async=true;s.id='lsInitScript';
    s.src='https://livesupporti.com/Scripts/clientAsync.js?acc=cfcc5660-6efc-4210-98a9-f26b0a7b4dd6&skin=Air';
    var scr=document.getElementsByTagName('script')[0];scr.parentNode.appendChild(s, scr);
    })();
